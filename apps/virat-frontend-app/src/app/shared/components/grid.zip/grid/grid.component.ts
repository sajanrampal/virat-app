import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { GridService } from './grid.service';

@Component({
    selector:'virat-app-grid',
    templateUrl: './grid.component.html',
    styleUrls:['grid.component.scss'],
    providers:[GridService]
})
export class GridComponent implements OnInit,OnChanges{
    title: string
    @Input() headers: [];
    @Input() data: [];
    // headers = ['Id','Name','Class','Section', 'action', 'keyId']
    // data = [
    //     {
    //         id:1,
    //         name:'sajan',
    //         class:'bca',
    //         section:'a',
    //         action:'go',
    //         keyId:'sajanrampal'
    //     },
    //     {
    //         id:2,
    //         name:'sajan',
    //         class:'bca',
    //         section:'a',
    //         action:'go',
    //         keyId:'sajanrampal'
    //     },
    //     {
    //         id:3,
    //         name:'sajan',
    //         class:'bca',
    //         section:'a',
    //         action:'go',
    //         keyId:'sajanrampal'
    //     },
    //     {
    //         id:4,
    //         name:'sajan',
    //         class:'bca',
    //         section:'a',
    //         action:'go',
    //         keyId:'sajanrampal'
    //     },
    //     {
    //         id:5,
    //         name:'sajan',
    //         class:'bca',
    //         section:'a',
    //         action:'go',
    //         keyId:'sajanrampal'
    //     }
    // ]
    ngOnChanges(changes: SimpleChanges): void {
        if (changes) {
          if (changes['headers'] && changes['headers'].currentValue) {
            this.headers = changes['headers'].currentValue;
          } else if (changes['data'] && changes['data'].currentValue) {
            this.data = changes['data'].currentValue;
          } 
        }
      }

    ngOnInit(){
        console.log(this.headers)
        console.log(this.data)
    }
}