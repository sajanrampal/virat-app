import { Injectable } from '@angular/core';

 @Injectable()

 export class GridService{
    // eslint-disable-next-line @typescript-eslint/no-empty-function
    constructor(){}
 }